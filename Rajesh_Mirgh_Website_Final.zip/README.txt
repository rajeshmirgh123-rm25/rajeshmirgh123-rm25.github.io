RAJESH MIRGH WEBSITE
====================

This is a static website package.

To preview:
- Keep index.html and Photograph.jpg in the same folder.
- Double-click index.html to open it in Chrome/Edge.

To publish:
- Upload both files to a web host, or use GitHub Pages / another static hosting service.

Files:
- index.html
- Photograph.jpg
